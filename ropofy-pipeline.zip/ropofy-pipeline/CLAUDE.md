# Pipeline de diagnóstico comercial Ropofy

Esta carpeta convierte transcripciones de sesiones estratégicas en propuestas
(`propuesta.json`) mediante tres skills encadenadas con compuertas de validación.
El renderizador del lienzo es otra aplicación y consume el `propuesta.json`
que aquí se produce.

---

## Cómo se usa (el consultor)

1. Crear `clientes/<cliente>/entrada/` y soltar ahí la(s) transcripción(es),
   con fecha en el nombre: `2026-08-14-sesion-1.docx`.
2. Decir: **"corre el diagnóstico de <cliente>"**.
3. Recoger los tres JSON en `clientes/<cliente>/salida/` y la agenda de la
   segunda llamada que se entrega al final.

`<cliente>` es un nombre corto sin espacios ni tildes: `activos`, `ayc`.

---

## Cuando el usuario pida "corre el diagnóstico de <cliente>"

Ejecuta las tres etapas **en orden y sin pedir confirmación entre ellas**,
corriendo el validador de cada una antes de pasar a la siguiente y
deteniéndote si alguno falla.

**Etapa 1 — `extraccion-diagnostico`.** Lee su SKILL.md y su contrato de ficha
completos. Produce `clientes/<cliente>/salida/ficha-<cliente>.json` desde las
transcripciones de `clientes/<cliente>/entrada/` (si hay varias, se consolidan
en una sola ficha). Convierte los .docx a texto plano primero. Valida:

    python3 .claude/skills/extraccion-diagnostico/scripts/validar_ficha.py \
      clientes/<cliente>/salida/ficha-<cliente>.json /tmp/trans-<cliente>.txt

Después haz la auto-revisión J1-J6 de
`.claude/skills/extraccion-diagnostico/references/criterios-evaluacion.md`:
una línea por criterio, pasa o duda concreta.

**Etapa 2 — `evaluacion-modular`.** Revalida la ficha (compuerta de entrada),
lee su SKILL.md y el catálogo de fugas COMPLETO. Produce
`diagnostico-<cliente>.json`. La nota la escribe el script, nunca el modelo:

    python3 .claude/skills/evaluacion-modular/scripts/calcular_nota.py \
      clientes/<cliente>/salida/diagnostico-<cliente>.json
    python3 .claude/skills/evaluacion-modular/scripts/validar_diagnostico.py \
      clientes/<cliente>/salida/diagnostico-<cliente>.json \
      .claude/skills/evaluacion-modular/references/catalogo-fugas.md \
      clientes/<cliente>/salida/ficha-<cliente>.json

**Etapa 3 — `seleccion-propuesta`.** Revalida ficha y diagnóstico, usa
`libreria/componentes.json`, y produce `propuesta-<cliente>-v1.json`. Copia la
política comercial desde `politica-comercial.json`. Instancias, multiplicador y
precios los escribe el script:

    python3 .claude/skills/seleccion-propuesta/scripts/calcular_condicion.py \
      clientes/<cliente>/salida/propuesta-<cliente>-v1.json \
      clientes/<cliente>/salida/ficha-<cliente>.json
    python3 .claude/skills/seleccion-propuesta/scripts/validar_propuesta.py \
      clientes/<cliente>/salida/propuesta-<cliente>-v1.json \
      libreria/componentes.json \
      clientes/<cliente>/salida/diagnostico-<cliente>.json

**Entrega final, siempre en este formato:**

1. Tabla de los tres archivos con su ruta y su línea de validación.
2. **Agenda de la segunda llamada**: los `no_capturado` de la ficha
   priorizados — primero los que cambian plan o precio.
3. **Decisiones que requieren criterio humano**: plan recomendado con su razón,
   ajustes manuales de instancias, advertencias que quedaron en pie.

---

## Reglas de la casa (aplican a cualquier tarea en esta carpeta)

1. **El modelo decide QUÉ, Python decide CUÁNTO.** Toda cifra —nota,
   instancias, multiplicador, precios— la escriben los scripts de las skills.
   Prohibido calcular números mentalmente o editarlos a mano en los JSON.
2. **Compuertas duras.** Un validador con exit 1 bloquea la etapa siguiente. Se
   corrige el archivo, jamás se relaja el contrato. Tras 3 intentos fallidos:
   detenerse y reportar los errores del validador textuales, sin parafrasear.
3. **Pureza de etapa.** La ficha registra, el diagnóstico juzga, la propuesta
   ofrece. La ficha no evalúa, el diagnóstico no propone, la propuesta no
   dibuja. La tentación de adelantar contenido significa que falta un campo:
   va en advertencias, no se cuela.
4. **No inferir en la etapa 1.** Lo que no se dijo en la sesión es
   `no_capturado`, y eso es un producto: es la agenda de la segunda llamada.
   Una ficha sin huecos es señal de invención.
5. **Política comercial:** vive en `politica-comercial.json` y solo la edita
   Jaime. Si falta o está incompleta, detenerse y pedirla — nunca inventar
   precios ni tramos.
6. **Nada de HTML ni lienzos aquí.** Esta carpeta termina en `propuesta.json`.
7. **Versiones de propuesta.** Si una observación del cliente cambia el
   alcance, la propuesta nueva es `-v2`; la anterior **nunca se edita ni se
   borra** (el expediente del cliente es su historial).
8. Leer el SKILL.md completo de cada etapa antes de ejecutarla, incluidas sus
   trampas conocidas. No trabajar de memoria.

---

## Estructura

- `clientes/<cliente>/entrada/` — transcripciones crudas (.docx, .txt) con fecha
- `clientes/<cliente>/salida/` — ficha, diagnóstico y propuesta de ese cliente
- `clientes/_ejemplo-activos/` — expediente completo terminado, como referencia
- `libreria/componentes.json` — librería compilada, **única para todos los clientes**
- `politica-comercial.json` — precios base, tramos de factor, tope de descuento
- `.claude/skills/` — las tres etapas con sus contratos, ejemplos y validadores
- `.claude/commands/diagnostico.md` — el mismo flujo como comando de Claude Code

---

## Mantenimiento

**Actualizar la librería** (cuando cambien los `modulo-*.md`): reemplazarlos en
`.claude/skills/seleccion-propuesta/references/modulos/` y recompilar:

    python3 .claude/skills/seleccion-propuesta/scripts/compilar_libreria.py \
      .claude/skills/seleccion-propuesta/references/modulos libreria/componentes.json

Debe reportar el total y un hash de versión. Ese hash queda registrado en cada
propuesta: es lo que permite saber si una propuesta vieja se hizo con librería
vieja. Estado conocido al montar esta carpeta: **81 componentes, hash
`639f4fc256`, distribución 30 fundamental / 29 avanzado / 21 inteligente**, más
un componente sin plan (la integración de plataforma propia — correcto por V11:
lo no nativo no viaja dentro del plan).

**Carpeta compartida:** esta carpeta vive en OneDrive compartido. La librería y
la política son únicas y compartidas a propósito — nadie trabaja sobre copias
sueltas, porque las copias derivan.
